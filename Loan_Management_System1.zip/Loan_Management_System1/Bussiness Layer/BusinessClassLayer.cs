﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Layer;
using Domain_Layer;

namespace Bussiness_Layer
{

    public class Customer_BL
    {
        CustomerDL datalayer = new CustomerDL();
        public Customer InsertCustomer(Customer customer)
        {
            return datalayer.InsertCustomerDL(customer);
        }
        public decimal GetinterestRateBL(Customer customer)
        {

            var a = Convert.ToDecimal(datalayer.GetInterestRateDL(customer));
            return a;
        }
        public Customer CheckCustomerLoginBL(Customer customer)
        {
            return datalayer.CheckCustomerLoginDL(customer);

        }

    }

    public class EmployeeBL
    {
        CustomerDL datalayer = new CustomerDL();
        public Employee CheckEmployeeLoginBL(Employee employeeuser)
        {
            return datalayer.CheckEmployeeLoginDL(employeeuser);
        }
    }
    public class IdseachBL
    {
        CustomerDL datalayerId = new CustomerDL();
        public IdSearch GetLoanDetaillsByIdBL(IdSearch idsearch)
        {
            return datalayerId.GetLoanDetailsByIdDL(idsearch);
        }
    }
    public class UpdateLoanDetailsBL
    {
        CustomerDL datalayerLoan = new CustomerDL();
        public bool UpdateLoanDetailBL(Employee updatedloan)
        {
            return datalayerLoan.UpdateLoanDetailsbyEmpDL(updatedloan);
        }
    }

}
