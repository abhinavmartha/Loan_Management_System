﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Layer;
using LoanManagementPropertiesDL;

namespace Bussiness_Layer
{

    public class Customer_BL
    {
        CustomerDL datalayer = new CustomerDL();
        public int InsertCustomer(Customer customer)
        {
            return datalayer.InsertCustomerDL(customer);
        }
        public decimal GetinterestRateBL(Customer customer)
        {
           
            var a = Convert.ToDecimal(datalayer.GetInterestRateDL(customer));
            return a;
        }
        public Customer CheckCustomerLoginBL(Customer customer)
        {
            return datalayer.CheckCustomerLoginDL(customer);

        }

    }

    public class EmployeeBL
    {
        CustomerDL datalayer = new CustomerDL();
        public Employee CheckEmployeeLoginBL(Employee employeeuser)
        {
            return datalayer.CheckEmployeeLoginDL(employeeuser);
        }
    }
    public class IdseachBL
    {
        CustomerDL datalayerId = new CustomerDL();
        public IdSearch GetLoanDetaillsByEmp(IdSearch idsearch)
        {
            return datalayerId.GetLoanDetailsByIdDL(idsearch);
        }
    }
    public class UpdateLoanDetailsBL
    {
        CustomerDL datalayerLoan = new CustomerDL();
        public bool UpdateLoanDetailBL(Employee updatedloan)
        {
            return datalayerLoan.UpdateLoanDetailsbyEmpDL(updatedloan);
        }
    }
    public class LoanRegistrationBL
    {
        CustomerDL RegistrationBL = new CustomerDL();
        public int GetLoanDetaillsByIdBL(IdSearch idsearch)
        {
            return RegistrationBL.LoanRegistrationDL(idsearch);
        }
    }
    public class DeleteCustomerBL
    {
        CustomerDL deletecustomerbyId = new CustomerDL();
        public void DeleteCustomerByIdBL(Customer customer)
        {
            deletecustomerbyId.DeleteCustomerDL(customer);
        }
    }
    public class ModifyCustomerBL
    {
        CustomerDL UpdateCustomer = new CustomerDL();
        public void ModifyCustomerByDetails(Customer customer)
        {
            UpdateCustomer.ModifyCustomerDL(customer);
        }
    }
    public class GetLoanDetailsBL
    {
        CustomerDL getloanadetails = new CustomerDL();
        public Customer GetLoanDetailsbyIDBL(Customer customer)
        {
            return getloanadetails.GetLoanDetailsDL(customer);
        }
    }
}
