﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Domain_Layer;
using Bussiness_Layer;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        Customer_BL customer_bl = new Customer_BL();

        private void btn_Insert_Click(object sender, RoutedEventArgs e)
        {
            Customer obj = new Customer()
            {
                CustomerName = txt_Customer_Name.Text,
                ContactNumber = int.Parse(txt_Contact_Number.Text),
                Email=txt_Email_Id.Text,
                DOB=DateTime.Parse(txt_Date_Of_Birth.Text),
                PAN=txt_PAN.Text,
                Aadhar=int.Parse(txt_Aadhar.Text)
            };
            customer_bl.InsertCustomer(obj);
            MessageBox.Show("You are successfully Registered");
        }
    }
}
