﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanManagementPropertiesDL
{
    
        public class Customer
        {
       
            public int CustomerId { get; set; }
            public string CustomerName { get; set; }
            public long ContactNumber { get; set; }
            public string Email { get; set; }
            public DateTime DOB { get; set; }
            public string PAN { get; set; }
            public string Aadhar { get; set; }
            public string LoanType { get; set; }
            public decimal InterestRate { get; }
            public string Password { get; set; }
            public int LoanAmount { get; set; }
            public bool PasswordIncorrect { get; set; }
            public bool UserNotRegistered { get; set; }
        public int LoanID { get; set; }
        public int SanctionedAmount { get; set; }
        public int RemainingAmount { get; set; }
        public int EMIAmount { get; set; }
        public string LoanStatus { get; set; }
        public int EMIMonths { get; set; }

        }

        public class User
        {
            public int CustomerId { get; set; }
           public string password { get; set; }
        public bool PasswordIncorrect { get; set; }
        public bool UserNotRegistered { get; set; }
    }
        public class EmployeeUser
        {
            public int EmpId { get; set; }
            public string EmployeeName { get; set; }
            public bool PasswordIncorrectEmp { get; set; }
            public bool UserNotRegisteredEmp { get; set; }
            public string Password { get; set; }
        }
    public class IdSearch
    {
        public int LoanId { get; set; }
        public int CustomerId { get; set; }
        public int LoanAmount { get; set; }
        public string CibilScore { get; set; }
        public int LoanType { get; set; }

    }
}

