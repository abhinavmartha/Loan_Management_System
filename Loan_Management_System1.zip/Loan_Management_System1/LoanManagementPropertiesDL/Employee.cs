﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanManagementPropertiesDL
{
  
        public class Employee
        {
            public int EmpId { get; set; }
            public string EmployeeName { get; set; }
            public string ContactNumber { get; set; }
            public string Password { get; set; }

            public int EMIAmount { get; }
            public DateTime EMIMonths { get; }
            public bool IsPasswordIncorrectEmp { get; set; }
            public bool UserNotRegisteredEmp { get; set; }
            public int LoanId { get; set; }
            public int SanctionedAmount { get; set; }
            public int ApprovalStatus { get; set; }
        }
    }

