﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanManagementPropertiesDL
{
        public class IdSearch
        {
            public int LoanId { get; set; }
            public int CustomerId { get; set; }
            public int LoanAmount { get; set; }
            public string CibilScore { get; set; }
            public string LoanType { get; set; }

        }
    }

