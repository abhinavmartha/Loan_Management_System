﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain_Layer;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace Data_Layer
{
    public class CustomerDL
    {
        string dbpath = ConfigurationManager.ConnectionStrings["LoanConnection"].ConnectionString;

        SqlConnection sqlcon;
        SqlCommand sqlcmd;

        public Customer InsertCustomerDL(Customer customer)
        {
            var id = new Customer();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
        
            sqlcmd = new SqlCommand("usp_Insert_CustomerDetails_Entry", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue ("@CustomerName", customer.CustomerName);
            sqlcmd.Parameters.AddWithValue ("@ContactNumber", customer.ContactNumber);
            sqlcmd.Parameters.AddWithValue ("@Email", customer.Email);
            sqlcmd.Parameters.AddWithValue ("@Password", customer.Password);
            sqlcmd.Parameters.AddWithValue ("@PAN", customer.PAN);
            sqlcmd.Parameters.AddWithValue ("@Aadhar", customer.Aadhar);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                id.CustomerId = Convert.ToInt32(rdr["CustomerId"]);

            }
            sqlcon.Close();
            sqlcon.Dispose();
            return id;
        }
        public void DeleteEmployeeDL(Customer customer)
        {
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            //Delete Statement
            string deleteCustomer = $"delete from tbl_Employee where EmpID = {customer.CustomerId}";
            //To execute command
            sqlcmd = new SqlCommand(deleteCustomer, sqlcon);
            sqlcon.Close();
            sqlcon.Dispose();

        }
        public decimal GetInterestRateDL(Customer customer)
        {
                sqlcon = new SqlConnection(dbpath);
                sqlcon.Open();
            decimal columnValue=0;

                sqlcmd = new SqlCommand("usp_Get_Interest_Rate", sqlcon);
                sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@LoanType", customer.LoanType);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                 columnValue = Convert.ToDecimal(rdr["InterestRate"]);

            }
            
                sqlcon.Close();
            return columnValue;
       }
        public Customer CheckCustomerLoginDL(Customer customer)
        {
            var customercheck = new Customer();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("CustomerLogin", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@CustomerID", customer.CustomerId);
            sqlcmd.Parameters.AddWithValue("@Password", customer.Password);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                customercheck.PasswordIncorrect = Convert.ToBoolean(rdr["PasswordIncorrect"]);
                customercheck.UserNotRegistered = Convert.ToBoolean(rdr["UserNotRegistered"]);

            }
            sqlcon.Close();
            sqlcon.Dispose();
            return customercheck;
        }
        public Employee CheckEmployeeLoginDL(Employee employee)
        {
            var employeecheck = new Employee();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("EmployeeLogin", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@EmpId", employee.EmpId);
            sqlcmd.Parameters.AddWithValue("@password", employee.Password);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                employeecheck.IsPasswordIncorrectEmp = Convert.ToBoolean(rdr["PasswordIncorrect"]);
                employeecheck.UserNotRegisteredEmp = Convert.ToBoolean(rdr["UserNotRegisteredEmp"]);

            }
            sqlcon.Close();
            sqlcon.Dispose();
            return employeecheck;
        }
        public IdSearch GetLoanDetailsByIdDL(IdSearch idsearch)
        {
            var customerid = new IdSearch();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("GetLoanDetailsByCustomerId", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@CustomerId", customerid.CustomerId);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                customerid.LoanType = Convert.ToString(rdr["LoanType"]);
                customerid.CibilScore = Convert.ToString(rdr["CibilScore"]);
                customerid.LoanAmount = Convert.ToInt32(rdr["LoanAmount"]);
                customerid.LoanAmount = Convert.ToInt32(rdr["LoanId"]);
            }
            sqlcon.Close();
            sqlcon.Dispose();
            return customerid;
        }
        public bool UpdateLoanDetailsbyEmpDL(Employee updateloandetails)
        {
            //var updateloan = new UpdateLoanDetails();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("UpdateLoanStatus", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@LoanId", updateloandetails.LoanId);
            sqlcmd.Parameters.AddWithValue("@SanctionedAmount", updateloandetails.SanctionedAmount);
            sqlcmd.Parameters.AddWithValue("@ApprovalStatus", updateloandetails.ApprovalStatus);
            sqlcmd.ExecuteNonQuery();
            sqlcon.Close();
            sqlcon.Dispose();
            return true;
        }

    }
}
