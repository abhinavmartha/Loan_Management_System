﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LoanManagementPropertiesDL;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace Data_Layer
{
    public class CustomerDL
    {
        string dbpath = ConfigurationManager.ConnectionStrings["LoanConnection"].ConnectionString;

        SqlConnection sqlcon;
        SqlCommand sqlcmd;

        public int InsertCustomerDL(Customer customer)
        {
            //var customerid = new Customer();
            int CustomerId = 0;
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();

            sqlcmd = new SqlCommand("usp_Insert_CustomerDetails_Entry", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@CustomerName", customer.CustomerName);
            sqlcmd.Parameters.AddWithValue("@ContactNumber", customer.ContactNumber);
            sqlcmd.Parameters.AddWithValue("@Email", customer.Email);
            sqlcmd.Parameters.AddWithValue("@Password", customer.Password);
            sqlcmd.Parameters.AddWithValue("@PAN", customer.PAN);
            sqlcmd.Parameters.AddWithValue("@Aadhar", customer.Aadhar);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                CustomerId = rdr.GetInt32(0);

            }
            sqlcon.Close();
           
            sqlcon.Dispose();
            return CustomerId;
        }
        public void DeleteCustomerDL(Customer customer)
        {

            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            //Delete Statement
            string deleteCustomer = $"delete from tbl_Customer where CustomerId = {customer.CustomerId}";
           
            //To execute command
            sqlcmd = new SqlCommand(deleteCustomer, sqlcon);
            sqlcmd.ExecuteNonQuery();
            sqlcon.Close();
            sqlcon.Dispose();

        }
        public void ModifyCustomerDL(Customer customer)
        {
            var id = new Customer();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();

            sqlcmd = new SqlCommand("UpdateCustomerDetails", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@CustomerId", customer.CustomerId);
            sqlcmd.Parameters.AddWithValue("@CustomerName", customer.CustomerName);
            sqlcmd.Parameters.AddWithValue("@ContactNumber", customer.ContactNumber);
            sqlcmd.Parameters.AddWithValue("@Email", customer.Email);
            sqlcmd.Parameters.AddWithValue("@PAN", customer.PAN);
            sqlcmd.Parameters.AddWithValue("@Aadhar", customer.Aadhar);
            sqlcmd.ExecuteNonQuery();
            sqlcon.Close();
            sqlcon.Dispose();

        }
        public decimal GetInterestRateDL(Customer customer)
        {
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            decimal columnValue = 0;

            sqlcmd = new SqlCommand("usp_Get_Interest_Rate", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@LoanType", customer.LoanType);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                columnValue = Convert.ToDecimal(rdr["InterestRate"]);

            }

            sqlcon.Close();
            return columnValue;
        }
        public Customer CheckCustomerLoginDL(Customer customer)
        {
            var customercheck = new Customer();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("CustomerLogin", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@CustomerID", customer.CustomerId);
            sqlcmd.Parameters.AddWithValue("@Password", customer.Password);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                customercheck.PasswordIncorrect = Convert.ToBoolean(rdr["PasswordIncorrect"]);
                customercheck.UserNotRegistered = Convert.ToBoolean(rdr["UserNotRegistered"]);

            }
            sqlcon.Close();
            sqlcon.Dispose();
            return customercheck;
        }
        public Employee CheckEmployeeLoginDL(Employee employee)
        {
            var employeecheck = new Employee();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("EmployeeLogin", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@EmpId", employee.EmpId);
            sqlcmd.Parameters.AddWithValue("@password", employee.Password);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                employeecheck.IsPasswordIncorrectEmp = Convert.ToBoolean(rdr["PasswordIncorrect"]);
                employeecheck.UserNotRegisteredEmp = Convert.ToBoolean(rdr["UserNotRegisteredEmp"]);

            }
            sqlcon.Close();
            sqlcon.Dispose();
            return employeecheck;
        }
        public IdSearch GetLoanDetailsByIdDL(IdSearch idsearch)
        {
            var customerid = new IdSearch();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("GetLoanDetailsByCustomerId", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@CustomerId", customerid.CustomerId);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                customerid.LoanType = Convert.ToString(rdr["LoanType"]);
                customerid.CibilScore = Convert.ToString(rdr["CibilScore"]);
                customerid.LoanAmount = Convert.ToInt32(rdr["LoanAmount"]);
                customerid.LoanAmount = Convert.ToInt32(rdr["LoanId"]);
            }
            sqlcon.Close();
            sqlcon.Dispose();
            return customerid;
        }
        public bool UpdateLoanDetailsbyEmpDL(Employee updateloandetails)
        {
            //var updateloan = new UpdateLoanDetails();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("UpdateLoanStatus", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@LoanId", updateloandetails.LoanId);
            sqlcmd.Parameters.AddWithValue("@SanctionedAmount", updateloandetails.SanctionedAmount);
            sqlcmd.Parameters.AddWithValue("@ApprovalStatus", updateloandetails.ApprovalStatus);
            sqlcmd.ExecuteNonQuery();
            sqlcon.Close();
            sqlcon.Dispose();
            return true;
        }
        public IdSearch LoanRegistrationDL(IdSearch idsearch)
        {
            IdSearch LoanIdValue = new IdSearch();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("LoanRegistration", sqlcon);
            //SqlParameter LoanId = new SqlParameter("LoanId",SqlDbType.Int);
            //LoanId.Direction = ParameterDirection.Output;
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@CustomerId", idsearch.CustomerId);
            sqlcmd.Parameters.AddWithValue("@LoanAmount", idsearch.LoanAmount);

            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                LoanIdValue.LoanId = Convert.ToInt32(rdr["LastInsertedId"]);

            }
            sqlcon.Close();
            sqlcon.Dispose();
            return LoanIdValue;
            //sqlcon.Close();
            //sqlcon.Dispose();
            //return customerid;
        }
        public Customer GetLoanDetailsDL(Customer customer)
        {
            var customerid = new Customer();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("GetLoanDetails", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@CustomerId", customer.CustomerId);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                customerid.LoanID = Convert.ToInt32(rdr["LoanID"]);
                customerid.LoanStatus = Convert.ToString(rdr["LoanStatus"]);
                customerid.SanctionedAmount = Convert.ToInt32(rdr["SanctionedAmount"]);
                customerid.RemainingAmount = Convert.ToInt32(rdr["RemainingAmount"]);
                customerid.EMIAmount = Convert.ToInt32(rdr["EMIAmount"]);
                customerid.RemainingAmount = Convert.ToInt32(rdr["RemainingAmount"]);
            }
            sqlcon.Close();
            sqlcon.Dispose();
            return customerid;
        }
    }
}
