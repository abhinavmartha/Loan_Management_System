﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LoanManagementPropertiesDL;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace Data_Layer
{
    public class CustomerDL
    {
        
        string dbpath = ConfigurationManager.ConnectionStrings["LoanConnection"].ConnectionString;
        // connection to the database
        SqlConnection sqlcon;
        SqlCommand sqlcmd;

        public int InsertCustomerDL(Customer customer)
        {
            //var customerid = new Customer();
            int CustomerId = 0;
            //Declaring an integer variable to return
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            //opening the connection
            sqlcmd = new SqlCommand("usp_Insert_CustomerDetails_Entry", sqlcon);
            //calling the procedure
            sqlcmd.CommandType = CommandType.StoredProcedure;
            //specifying the type of procedure
            sqlcmd.Parameters.AddWithValue("@CustomerName", customer.CustomerName);
            sqlcmd.Parameters.AddWithValue("@ContactNumber", customer.ContactNumber);
            sqlcmd.Parameters.AddWithValue("@Email", customer.Email);
            sqlcmd.Parameters.AddWithValue("@Password", customer.Password);
            sqlcmd.Parameters.AddWithValue("@PAN", customer.PAN);
            sqlcmd.Parameters.AddWithValue("@Aadhar", customer.Aadhar);
            //passing input parameters to stored procedures
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            //reads value from table
            while (rdr.Read())
            {

                CustomerId = rdr.GetInt32(0);
                //to display customerid to customer
            }
            sqlcon.Close();
           //closing the connection
            sqlcon.Dispose();
            //disposing the connection
            return CustomerId;
            //returns customer id
        }
        public void DeleteCustomerDL(Customer customer)
        {

            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            //opening the connection to database
            //Delete Statement
            string deleteCustomer = $"delete from tbl_Customer where CustomerId = {customer.CustomerId}";
           //storing the query to execute into a string
            //To execute command
            sqlcmd = new SqlCommand(deleteCustomer, sqlcon);
            //executing the query
            sqlcmd.ExecuteNonQuery();
            //executes the query and doesn't return a value
            sqlcon.Close();
            //closing the connection
            sqlcon.Dispose();
            //Disposing the connection

        }
        public void ModifyCustomerDL(Customer customer)
        {
            var id = new Customer();
            //creating the instance of cutsomer class
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            //opening the connection

            sqlcmd = new SqlCommand("UpdateCustomerDetails", sqlcon);
            //calling the procedure
            sqlcmd.CommandType = CommandType.StoredProcedure;
            //specifying the type of procedure
            sqlcmd.Parameters.AddWithValue("@CustomerId", customer.CustomerId);
            sqlcmd.Parameters.AddWithValue("@CustomerName", customer.CustomerName);
            sqlcmd.Parameters.AddWithValue("@ContactNumber", customer.ContactNumber);
            sqlcmd.Parameters.AddWithValue("@Email", customer.Email);
            sqlcmd.Parameters.AddWithValue("@PAN", customer.PAN);
            sqlcmd.Parameters.AddWithValue("@Aadhar", customer.Aadhar);
            //passing inputs parameters to the procedure
            sqlcmd.ExecuteNonQuery();
            //executing the query
            sqlcon.Close();
            //closing the connection
            sqlcon.Dispose();
            //disposing the connection
        }
        public decimal GetInterestRateDL(Customer customer)
        {
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            //opening the connection
            decimal columnValue = 0;
            //declaring a variable
            sqlcmd = new SqlCommand("usp_Get_Interest_Rate", sqlcon);
            //calling the procedure
            sqlcmd.CommandType = CommandType.StoredProcedure;
            //type of procedure
            sqlcmd.Parameters.AddWithValue("@LoanType", customer.LoanType);
            //input parameters
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            //executing the query
            while (rdr.Read())
            {

                columnValue = Convert.ToDecimal(rdr["InterestRate"]);

            }
            //reading the values

            sqlcon.Close();
            //closing the connection
            sqlcon.Dispose();
            //Disposing the connection
            return columnValue;
            //returning the column value
        }
        public Customer CheckCustomerLoginDL(Customer customer)
        {
            var customercheck = new Customer();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("CustomerLogin", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@CustomerID", customer.CustomerId);
            sqlcmd.Parameters.AddWithValue("@Password", customer.Password);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                customercheck.PasswordIncorrect = Convert.ToBoolean(rdr["PasswordIncorrect"]);
                customercheck.UserNotRegistered = Convert.ToBoolean(rdr["UserNotRegistered"]);

            }
            sqlcon.Close();
            sqlcon.Dispose();
            return customercheck;
        }
        public Employee CheckEmployeeLoginDL(Employee employee)
        {
            var employeecheck = new Employee();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("EmployeeLogin", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@EmpId", employee.EmpId);
            sqlcmd.Parameters.AddWithValue("@password", employee.Password);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                employeecheck.IsPasswordIncorrectEmp = Convert.ToBoolean(rdr["PasswordIncorrect"]);
                employeecheck.UserNotRegisteredEmp = Convert.ToBoolean(rdr["UserNotRegisteredEmp"]);

            }
            sqlcon.Close();
            sqlcon.Dispose();
            return employeecheck;
        }
        public IdSearch GetLoanDetailsByIdDL(IdSearch idsearch)
        {
             var customerid = new IdSearch();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("GetLoanDetailsByCustomerId", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@CustomerId", idsearch.CustomerId);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                customerid.LoanType = rdr.GetInt32(1);
                customerid.CibilScore =rdr.GetString(8);
                customerid.LoanAmount = rdr.GetInt32(2);
                customerid.LoanId = rdr.GetInt32(0);
            }
            sqlcon.Close();
            sqlcon.Dispose();
            return customerid;
        }
        public bool UpdateLoanDetailsbyEmpDL(Employee updateloandetails)
        {
            //var updateloan = new UpdateLoanDetails();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("UpdateLoanStatus", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@LoanId", updateloandetails.LoanId);
            sqlcmd.Parameters.AddWithValue("@SanctionedAmount", updateloandetails.SanctionedAmount);
            sqlcmd.Parameters.AddWithValue("@ApprovalStatus", updateloandetails.ApprovalStatus);
            sqlcmd.ExecuteNonQuery();
            sqlcon.Close();
            sqlcon.Dispose();
            return true;
        }
        public int LoanRegistrationDL(IdSearch idsearch)
        {
            int Loanid = 0;
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("LoanRegistration", sqlcon);
            //SqlParameter LoanId = new SqlParameter("LoanId", SqlDbType.Int);
            //LoanId.Direction = ParameterDirection.Output;
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@CustomerId", idsearch.CustomerId);
            sqlcmd.Parameters.AddWithValue("@LoanAmount", idsearch.LoanAmount);

            SqlDataReader rdr = sqlcmd.ExecuteReader();
            while (rdr.Read())
            {

                Loanid = rdr.GetInt32(0);

            }
            sqlcon.Close();
            sqlcon.Dispose();
            return Loanid;
            //sqlcon.Close();
            //sqlcon.Dispose();
            //return customerid;
        }
        public Customer GetLoanDetailsDL(Customer customer)
        {
            var customerid = new Customer();
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
            sqlcmd = new SqlCommand("GetLoanDetails", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@CustomerId", customer.CustomerId);
            SqlDataReader rdr = sqlcmd.ExecuteReader();
            //while (rdr.Read())
            {

                customerid.LoanID = rdr.GetInt32(0);
                customerid.LoanStatus = rdr.GetString(5);
                customerid.SanctionedAmount =rdr.GetInt32(1);
                customerid.EMIAmount = rdr.GetInt32(3);
                customerid.EMIMonths = rdr.GetInt32(4);
                
            
            }
            sqlcon.Close();
            sqlcon.Dispose();
            return customerid;
        }
    }
}
