﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Bussiness_Layer;
using LoanManagementPropertiesDL;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for DeleteCustomerbyEmp.xaml
    /// </summary>
    public partial class DeleteCustomerbyEmp : Window
    {
        public DeleteCustomerbyEmp()
        {
            InitializeComponent();
        }
        DeleteCustomerBL deletecustomerbyid = new DeleteCustomerBL();
        private void Delete_Button_Click(object sender, RoutedEventArgs e)
        {
            if (txtCustomerID.Text == "" || txtReasons.Text == "")
            {
                MessageBox.Show("Please Enter The Customer Id and Reason");
            }
            else
            {
                Customer customer = new Customer()
                {
                    CustomerId = Convert.ToInt32(txtCustomerID.Text)
                };
                deletecustomerbyid.DeleteCustomerByIdBL(customer);
                MessageBox.Show("Successfully Deleted");
            }

        }

        private void Back_Button_Click(object sender, RoutedEventArgs e)
        {
            Employee_Approval_Page employeeapproval = new Employee_Approval_Page();
            employeeapproval.Show();
            this.Close();
        }
    }
}
