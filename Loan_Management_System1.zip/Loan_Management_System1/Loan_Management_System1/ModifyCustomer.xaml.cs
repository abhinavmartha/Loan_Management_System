﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Bussiness_Layer;
using LoanManagementPropertiesDL;


namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for ModifyCustomer.xaml
    /// </summary>
    public partial class ModifyCustomer : Window
    {
        public ModifyCustomer()
        {
            InitializeComponent();
        }

        ModifyCustomerBL modifyCustomerBL = new ModifyCustomerBL();

        private void Submit_Button_click(object sender, RoutedEventArgs e)
        {
            if (txt_Customer_Name.Text == "" || txt_Contact_Number.Text == "" || txt_Email_Id.Text == "" || txt_CustomerId.Text == "" || txt_PAN.Text == "" || txt_Aadhar.Text == "")
            {
                MessageBox.Show("Please Enter All the Details");
            }
            else
            {
                Customer customer = new Customer()
                {
                    CustomerId = Convert.ToInt32(txt_CustomerId.Text),
                    CustomerName = txt_Customer_Name.Text,
                    Email = txt_Email_Id.Text,
                    ContactNumber = Convert.ToInt64(txt_Contact_Number.Text),
                    PAN = txt_PAN.Text,
                    Aadhar = txt_Aadhar.Text
                };
                modifyCustomerBL.ModifyCustomerByDetails(customer);
            }
        }

        private void Back_Button_Click(object sender, RoutedEventArgs e)
        {
            Customeroptions customeroptions = new Customeroptions();
            customeroptions.Show();
            this.Close();
        }
    }
}
