﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using Bussiness_Layer;
using LoanManagementPropertiesDL;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for LoanRegistration.xaml
    /// </summary>
    public partial class LoanRegistration : Window
    {
        public LoanRegistration()
        {
            InitializeComponent();
        }
        LoanRegistrationBL loanregistrationbl = new LoanRegistrationBL();
        IdSearch LoanId = new IdSearch();


        private void Back_Button_Click(object sender, RoutedEventArgs e)
        {
            Types_of_Loans typesofloans = new Types_of_Loans();
            typesofloans.Show();
            this.Close();
        }


        private void textBox_Copy_TextChanged(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^(0-9)]").IsMatch(e.Text);
        }

        private void textBox_Copy1_TextChanged(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^(0-9)]").IsMatch(e.Text);
        }

        private void textBox_Copy2_TextChanged(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^(0-9 A-Z a-z @)]").IsMatch(e.Text);
        }

        private void textBox_Copy3_TextChanged(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^(0-9)]").IsMatch(e.Text);
        }

        private void textBox_Copy4_TextChanged(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^(0-9 A-Z a-z)]+").IsMatch(e.Text);

        }
        private void submit_Button_Click(object sender, RoutedEventArgs e)
        {
            if (txt_CustomerName.Text.Length == 0)
            {
                errormessage.Text = "**Enter name**";
                txt_CustomerName.Focus();
            }
            else if (!Regex.IsMatch(txt_CustomerName.Text, @"([a-zA-Z]{3,30}\s*)+"))
            {
                errormessage.Text = "**Enter a valid Name**";
                txt_CustomerName.Focus();
            }

           
            else if (!Regex.IsMatch(txt_EmailId.Text, @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"))
            {
                errormessage.Text = "**Enter a valid email**";
                txt_EmailId.Select(0, txt_EmailId.Text.Length);
                txt_EmailId.Focus();
            }

            else if (txt_ContactNumber.Text.Length == 0)
            {
                errormessage.Text = "**Enter contact number**";
                txt_ContactNumber.Focus();
            }
            else if (!Regex.IsMatch(txt_ContactNumber.Text, @"^[6-9][0-9]{9}$"))
            {
                errormessage.Text = "**Enter a valid Contact Number**";
                txt_ContactNumber.Focus();
            }
            else if (txtCustomer_Id.Text.Length == 0)
            {
                errormessage.Text = "**Enter CustomerId**";
                txtCustomer_Id.Focus();
            }
            else if (txt_EmailId.Text.Length == 0)
            {
                errormessage.Text = "**Enter an email**";
                txt_EmailId.Focus();
            }

            /////////////////////////////////////////

            else
            {
                IdSearch loanregistration = new IdSearch()
                {
                    LoanAmount = Convert.ToInt32(txt_LoanAmount.Text),
                    CustomerId = Convert.ToInt32(txtCustomer_Id.Text)

                };
                int Loanid;
                Loanid = loanregistrationbl.GetLoanDetaillsByIdBL(loanregistration);

                MessageBox.Show($"You have Successfully Submitted your Loan Application \n Your Loan Id is \t {Loanid}");

            }

          



        }

        private void close_Button_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }
    }
}
