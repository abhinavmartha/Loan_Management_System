﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using Bussiness_Layer;
using LoanManagementPropertiesDL;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for LoanRegistration.xaml
    /// </summary>
    public partial class LoanRegistration : Window
    {
        public LoanRegistration()
        {
            InitializeComponent();
        }
        LoanRegistrationBL loanregistrationbl = new LoanRegistrationBL();
        IdSearch LoanId = new IdSearch();
        

        private void Back_Button_Click(object sender, RoutedEventArgs e)
        {
            Types_of_Loans typesofloans = new Types_of_Loans();
            typesofloans.Show();
            this.Close();
        }
        

        private void textBox_Copy_TextChanged(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^(0-9)]").IsMatch(e.Text);
        }

        private void textBox_Copy1_TextChanged(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^(0-9)]").IsMatch(e.Text);
        }

        private void textBox_Copy2_TextChanged(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^(0-9 A-Z a-z @)]").IsMatch(e.Text);
        }

        private void textBox_Copy3_TextChanged(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^(0-9)]").IsMatch(e.Text);
        }

        private void textBox_Copy4_TextChanged(object sender, TextCompositionEventArgs e)
        {
            e.Handled = new Regex("[^(0-9 A-Z a-z)]+").IsMatch(e.Text);
        }
        private void submit_Button_Click(object sender, RoutedEventArgs e)
        {
            if (txt_LoanAmount.Text == "" || txtCustomer_Id.Text == "")
            {
                MessageBox.Show("Enter Loan Details");
            }
            else
            {
                IdSearch loanregistration = new IdSearch()
                {
                    LoanAmount = Convert.ToInt32(txt_LoanAmount.Text),
                    CustomerId = Convert.ToInt32(txtCustomer_Id.Text)

                };

                LoanId= loanregistrationbl.GetLoanDetaillsByIdBL(loanregistration);

                MessageBox.Show("You have Successfully Submitted your Loan Application \n" + "Your Loan Id is \t" + LoanId.LoanId);
                LoanDetails loandetails = new LoanDetails();
                loandetails.Show();
            }
        }

        private void txtCustomer_Id_TextChanged(object sender, TextChangedEventArgs e)
        {

            string input = (sender as TextBox).Text; //1234567

            if (!Regex.IsMatch(input, @"^\d{1,5}|\d{0,5}\.\d{1,2}$"))
            {
                MessageBox.Show("Error!, check and try again");
            }
        }

        private void CustomerName_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!Regex.Match(txt_CustomerName.Text, "^[A-Z][a-z A-Z]*$").Success)
            {
                // first name was incorrect  
                MessageBox.Show("Invalid Customer name", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                txt_CustomerName.Focus();
                return;
            }
        }

        private void txt_ContactNumber_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!Regex.Match(txt_ContactNumber.Text, @"^\+?[0-9-]+$").Success)
            {
                // first name was incorrect  
                MessageBox.Show("Invalid Contact Number", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                txt_CustomerName.Focus();
                return;
            }
        }

        private void txt_EmailId_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!Regex.Match(txt_EmailId.Text, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$").Success)
            {
                // first name was incorrect  
                MessageBox.Show("Invalid Email Id", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                txt_EmailId.Focus();
                return;
            }
        }

        private void txt_LoanAmount_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!Regex.Match(txt_LoanAmount.Text, @"^\+?[0-9-]+$").Success)
            {
                // first name was incorrect  
                MessageBox.Show("Invalid Amount", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                txt_LoanAmount.Focus();
                return;
            }
        }

        private void txt_Occupation_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!Regex.Match(txt_Occupation.Text, "^[A-Z][a-z A-Z]*$").Success)
            {
                // first name was incorrect  
                MessageBox.Show("Invalid Name", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                txt_Occupation.Focus();
                return;
            }
        }
    }
}
