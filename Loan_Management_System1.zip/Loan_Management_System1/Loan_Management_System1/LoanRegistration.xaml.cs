﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for LoanRegistration.xaml
    /// </summary>
    public partial class LoanRegistration : Window
    {
        public LoanRegistration()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            LoanDetails loandetails = new LoanDetails();
            loandetails.Show();
            
        }

      

        //private void textBox_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(A-Z a-z)]+").IsMatch(e.Text);
        //}

        //private void textBox_Copy_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(0-9)]").IsMatch(e.Text);
        //}

        //private void textBox_Copy1_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(0-9)]").IsMatch(e.Text);
        //}

        //private void textBox_Copy2_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(0-9 A-Z a-z @)]").IsMatch(e.Text);
        //}

        //private void textBox_Copy3_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(0-9)]").IsMatch(e.Text);
        //}

        //private void textBox_Copy4_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(0-9 A-Z a-z)]+").IsMatch(e.Text);
        //}
    }
}
