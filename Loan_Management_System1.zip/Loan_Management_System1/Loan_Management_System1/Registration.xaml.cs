﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Domain_Layer;
using Bussiness_Layer;
using System.Text.RegularExpressions;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public Registration()
        {
            InitializeComponent();
        }
        Customer_BL customer_bl = new Customer_BL();

        private void btn_Insert_Click(object sender, RoutedEventArgs e)
        {
            Customer customer = new Customer();
            Customer obj = new Customer()
            {
                CustomerName = txt_Customer_Name.Text,
                ContactNumber = long.Parse(txt_Contact_Number.Text),
                Email = txt_Email_Id.Text,
                Password = txt_Password.Password,
                PAN = txt_PAN.Text,
                Aadhar = txt_Aadhar.Text
            };
            customer=customer_bl.InsertCustomer(obj);
            MessageBox.Show("You are Successfully Registered, Your Customer_Id is" + customer.CustomerId);
            
           
        }

        //private void txt_Customer_Name_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(A-Z a-z)]+").IsMatch(e.Text);
        //}

        //private void txt_Contact_Number_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("^+(?:[0-9].?){6,14}[0-9]").IsMatch(e.Text);
        //}

        //private void txt_Email_Id_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(0-9 A-Z a-z @)]+").IsMatch(e.Text);
        //}

        //private void txt_PAN_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(0-9 A-Z)]+").IsMatch(e.Text);
        //}

        //private void txt_Aadhar_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(0-9)]+").IsMatch(e.Text);
        //}

        private void txt_Customer_Name_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txt_Customer_Name_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }
    }
}
