﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Bussiness_Layer;
using LoanManagementPropertiesDL;
using System.Text.RegularExpressions;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public Registration()
        {
            InitializeComponent();
        }
        Customer_BL customer_bl = new Customer_BL();

        private void btn_Insert_Click(object sender, RoutedEventArgs e)
        {
            if (txt_Customer_Name.Text == "" || txt_Contact_Number.Text == "" || txt_Email_Id.Text == "" || txt_Password.Password == "" || txt_PAN.Text == "" || txt_Aadhar.Text == "")
            {
                MessageBox.Show("Please Enter All The Details");
            }
            else
            {
                Customer customer = new Customer();
                Customer obj = new Customer()
                {
                    CustomerName = txt_Customer_Name.Text,
                    ContactNumber = long.Parse(txt_Contact_Number.Text),
                    Email = txt_Email_Id.Text,
                    Password = txt_Password.Password,
                    PAN = txt_PAN.Text,
                    Aadhar = txt_Aadhar.Text
                };
                int customerId = customer_bl.InsertCustomer(obj);
                MessageBox.Show($"You are Successfully Registered, Your Customer_Id is{ customerId}");
            }
           
        }

        //private void txt_Customer_Name_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(A-Z a-z)]+").IsMatch(e.Text);
        //}

        //private void txt_Contact_Number_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("^+(?:[0-9].?){6,14}[0-9]").IsMatch(e.Text);
        //}

        //private void txt_Email_Id_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(0-9 A-Z a-z @)]+").IsMatch(e.Text);
        //}

        //private void txt_PAN_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(0-9 A-Z)]+").IsMatch(e.Text);
        //}

        //private void txt_Aadhar_TextChanged(object sender, TextCompositionEventArgs e)
        //{
        //    e.Handled = new Regex("[^(0-9)]+").IsMatch(e.Text);
        //}

  
      
        private void btn_Back_Click(object sender, RoutedEventArgs e)
        {
            HomePage homepage = new HomePage();
            homepage.Show();
            this.Close();
        }

        private void txt_Customer_Name_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            if (!Regex.Match(txt_Customer_Name.Text, "^[A-Z][a-z A-Z]*$").Success)
            {
                // first name was incorrect  
                MessageBox.Show("Invalid Customer name", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                txt_Customer_Name.Focus();
                return;
            }
        }

        private void txt_Contact_Number_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!Regex.Match(txt_Contact_Number.Text, @"^\+?[0-9-]+$").Success)
            {
                // first name was incorrect  
                MessageBox.Show("Invalid Contact Number", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                txt_Contact_Number.Focus();
                return;
            }
        }

        private void Close_Button_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            Customeroptions customeroptions = new Customeroptions();
            customeroptions.Show();
            this.Close();
        }

        //private void txt_Email_Id_TextChanged(object sender, TextChangedEventArgs e)
        //{
        //    //bool isEmail = Regex.IsMatch(txt_Email_Id.Text, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
        //    if (!Regex.Match(txt_Email_Id.Text, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase).Success)
        //    {
        //        // first name was incorrect  
        //        MessageBox.Show("Invalid Email Id", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
        //        txt_Email_Id.Focus();
        //        return;
        //    }
        //}

        //private void txt_PAN_TextChanged(object sender, TextChangedEventArgs e)
        //{
        //    if (!Regex.Match(txt_PAN.Text, "[A-Z]{5}[0-9]{4}[A-Z]{1}").Success)
        //    {
        //        // first name was incorrect  
        //        MessageBox.Show("Invalid PAN Id", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
        //        txt_PAN.Focus();
        //        return;
        //    }
        //}

        //private void txt_Aadhar_TextChanged(object sender, TextChangedEventArgs e)
        //{
        //    if (!Regex.Match(txt_Aadhar.Text, "[0-9]{12}").Success)
        //    {
        //        // first name was incorrect  
        //        MessageBox.Show("Invalid Aadhar Number", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
        //        txt_Aadhar.Focus();
        //        return;
        //    }
        //}
    }
}
