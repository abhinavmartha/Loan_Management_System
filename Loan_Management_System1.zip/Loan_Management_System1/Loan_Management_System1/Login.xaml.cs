﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using Bussiness_Layer;
using LoanManagementPropertiesDL;
namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }
        Customer customercheck = new Customer();
        User customeruser = new User();
        Customer_BL customerbl = new Customer_BL();


        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            Customer customer = new Customer()
            {
                CustomerId = Convert.ToInt32(txtCustomerID.Text),
                Password = Convert.ToString(txtPassword.Password)
            };
            customercheck=customerbl.CheckCustomerLoginBL(customer);
            if(customercheck.PasswordIncorrect==false&&customercheck.UserNotRegistered==false)
            {
                Customeroptions customeroptions = new Customeroptions();
                customeroptions.Show();
                this.Close();
            }
            else if(customercheck.PasswordIncorrect == true && customercheck.UserNotRegistered == false)
            {
                MessageBox.Show("Check your Password");
            }
            else
            {
                MessageBox.Show("User not Registered");
            }
        }

      

        private void txtCustomerID_TextChanged(object sender, TextChangedEventArgs e)
        {
            string input = (sender as TextBox).Text; //1234567

            if (!Regex.IsMatch(input, @"^\d{1,5}|\d{0,5}\.\d{1,2}$"))
            {
                MessageBox.Show("Error!, check and try again");
            }
        }
    }
}
