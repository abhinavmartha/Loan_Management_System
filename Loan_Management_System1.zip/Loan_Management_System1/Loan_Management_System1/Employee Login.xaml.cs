﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Bussiness_Layer;
using LoanManagementPropertiesDL;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for Employee_Login.xaml
    /// </summary>
    public partial class Employee_Login : Window
    {
        public Employee_Login()
        {
            InitializeComponent();
        }
        Employee employeecheck = new Employee();
        EmployeeBL employeebl = new EmployeeBL();

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {


            if (txtEmployeeId.Text == "" || txtPassword.Password == "")
            {
                MessageBox.Show("Please Enter Details");
            }

            else
            {
                try
                {
                    Employee employee = new Employee()
                    {

                        EmpId = Convert.ToInt32(txtEmployeeId.Text),

                        Password = Convert.ToString(txtPassword.Password)
                    };


                    employeecheck = employeebl.CheckEmployeeLoginBL(employee);


                    if (employeecheck.IsPasswordIncorrectEmp == false && employeecheck.UserNotRegisteredEmp == false)
                    {
                        Employee_Approval_Page employeeap = new Employee_Approval_Page();
                        employeeap.Show();
                        this.Close();
                    }
                    else if (employeecheck.IsPasswordIncorrectEmp == true && employeecheck.UserNotRegisteredEmp == false)
                    {
                        MessageBox.Show("Check your Password");
                    }
                    else
                    {
                        MessageBox.Show("User not Registered");
                    }

                }
                catch (System.FormatException FE)
                {
                    MessageBox.Show(FE.Message);
                }

            }

        }

        private void txtEmployeeId_TextChanged(object sender, TextChangedEventArgs e)
        {
            string input = (sender as TextBox).Text; //1234567

            if (!Regex.IsMatch(input, @"^\d{1,5}|\d{0,5}\.\d{1,2}$"))
            {
                MessageBox.Show("Error!, check and try again");
            }
        }
    }
}


