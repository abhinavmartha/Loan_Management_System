﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Domain_Layer;
using Bussiness_Layer;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for Employee_Approval_Page.xaml
    /// </summary>
    public partial class Employee_Approval_Page : Window
    {
        public Employee_Approval_Page()
        {
            InitializeComponent();
        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        IdseachBL idsearchBL = new IdseachBL();
        IdSearch idsearchDL = new IdSearch();
        private void Delete_Button_Click(object sender, RoutedEventArgs e)
        {

        }


        private void Search_Button_Click(object sender, RoutedEventArgs e)
        {
            IdSearch idSearch = new IdSearch()
            {
                CustomerId = Convert.ToInt32(customerIdBox.Text)
            };
            var id = idsearchBL.GetLoanDetaillsByIdBL(idSearch);
            if (id.LoanAmount == 0 || id.LoanType == "")
            {
                MessageBox.Show("The customer hasn't applied for loan");
                this.Close();
            }
            Lbl_LoanRequests.Content = id.LoanType;
            Lbl_CibilScore.Content = Convert.ToString(id.CibilScore);
            Lbl_RequestedAmount.Content = id.LoanAmount;
            LblLoanId.Content = id.LoanId;
        }
        UpdateLoanDetailsBL updateBL = new UpdateLoanDetailsBL();
        UpdateLoanDetails updateDetails = new UpdateLoanDetails();
        private void Approve_Button_Click(object sender, RoutedEventArgs e)
        {
            if(Convert.ToInt32(Lbl_RequestedAmount.Content)==0)
            {
                MessageBox.Show("You Cannot approve The Loan");
            }
            else if(Convert.ToString(Lbl_CibilScore.Content)=="Average")
            {
                
                MessageBox.Show("You Cannot approve The Loan");
            }
            else if(Convert.ToString(Lbl_CibilScore.Content)=="Poor")
            {
                MessageBox.Show("You cannot approve The Loan ");
            }
            Employee updateloandetails = new Employee()
            {
                LoanId = Convert.ToInt32(LblLoanId.Content),
                SanctionedAmount = Convert.ToInt32(txtSanctionedAmount.Text),
                ApprovalStatus = 2
            };
            updateBL.UpdateLoanDetailBL(updateloandetails);
            
        }
        UpdateLoanDetailsBL updatedata = new UpdateLoanDetailsBL();
        private void Reject_Button_Click(object sender, RoutedEventArgs e)
        {

            Employee updateloandetails = new Employee()
            {
                LoanId = Convert.ToInt32(LblLoanId.Content),
                SanctionedAmount = Convert.ToInt32(txtSanctionedAmount.Text),
                ApprovalStatus = 3


            };
            updatedata.UpdateLoanDetailBL(updateloandetails);
        }
    }
}
