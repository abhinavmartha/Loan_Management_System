﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Bussiness_Layer;
using LoanManagementPropertiesDL;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for Employee_Approval_Page.xaml
    /// </summary>
    public partial class Employee_Approval_Page : Window
    {
        public Employee_Approval_Page()
        {
            InitializeComponent();
        }

     
        IdseachBL idsearchBL = new IdseachBL();
        IdSearch idsearchDL = new IdSearch();
        private void Delete_Button_Click(object sender, RoutedEventArgs e)
        {
            DeleteCustomerbyEmp deletecustomer = new DeleteCustomerbyEmp();
            deletecustomer.Show();
            this.Close();
        }


        private void Search_Button_Click(object sender, RoutedEventArgs e)
        {
            IdSearch idSearch = new IdSearch()
            {
                CustomerId = Convert.ToInt32(customerIdBox.Text)
            };
            var id = idsearchBL.GetLoanDetaillsByIdBL(idSearch);
            //if (id.LoanAmount == 0 || id.LoanType == "")
            //{
            //    MessageBox.Show("The customer hasn't applied for loan");
               
            //}
            Lbl_LoanRequests.Content = id.LoanType;
            Lbl_CibilScore.Content = id.CibilScore;
            Lbl_RequestedAmount.Content = id.LoanAmount;
            LblLoanId.Content = id.LoanId;
        }
        UpdateLoanDetailsBL updateBL = new UpdateLoanDetailsBL();
      
        private void Approve_Button_Click(object sender, RoutedEventArgs e)
        {
            if(Convert.ToInt32(Lbl_RequestedAmount.Content)==0)
            {
                MessageBox.Show("You Cannot approve The Loan");
            }
            else if(Convert.ToString(Lbl_CibilScore.Content)=="Average")
            {
                
                MessageBox.Show("You Cannot approve The Loan");
            }
            else if(Convert.ToString(Lbl_CibilScore.Content)=="Poor")
            {
                MessageBox.Show("You cannot approve The Loan ");
            }
            Employee updateloandetails = new Employee()
            {
                LoanId = Convert.ToInt32(LblLoanId.Content),
                SanctionedAmount = Convert.ToInt32(txtSanctionedAmount.Text),
                ApprovalStatus = 2
            };
            updateBL.UpdateLoanDetailBL(updateloandetails);
            
        }
        UpdateLoanDetailsBL updatedata = new UpdateLoanDetailsBL();
        private void Reject_Button_Click(object sender, RoutedEventArgs e)
        {

            Employee updateloandetails = new Employee()
            {
                LoanId = Convert.ToInt32(LblLoanId.Content),
                SanctionedAmount = Convert.ToInt32(txtSanctionedAmount.Text),
                ApprovalStatus = 3


            };
            updatedata.UpdateLoanDetailBL(updateloandetails);
        }

        private void textbox_CustomerId(object sender, TextChangedEventArgs e)
        {
            string input = (sender as TextBox).Text; //1234567

            if (!Regex.IsMatch(input, @"^\d{1,5}|\d{0,5}\.\d{1,2}$"))
            {
                MessageBox.Show("Error!, check and try again");
            }
        }

        private void textbox_SanctionedAmount(object sender, TextChangedEventArgs e)
        {
            if (!Regex.Match(txtSanctionedAmount.Text, @"^\+?[0-9-]+$").Success)
            {
                // first name was incorrect  
                MessageBox.Show("Invalid Contact Number", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                txtSanctionedAmount.Focus();
                return;
            }
        }
    }
}
