﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Domain_Layer;
using Bussiness_Layer;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for Types_of_Loans.xaml
    /// </summary>
    public partial class Types_of_Loans : Window
    {
        public Types_of_Loans()
        {
            InitializeComponent();
        }
        readonly Customer_BL instance = new Customer_BL();
        private void Education_Loan_Checked(object sender, RoutedEventArgs e)
        {
           
            string loan = "Education Loan";
            Customer obj = new Customer()
            {
                LoanType = loan
            };
            instance.GetinterestRateBL(obj);
            
           
        }

        private void Home_Loan_Checked(object sender, RoutedEventArgs e)
        {
            string loan = "Home Loan";
            Customer obj = new Customer()
            {
                LoanType = loan
            };
            instance.GetinterestRateBL(obj);

            MessageBox.Show("move to next page");

        }

        private void Vehicle_Loan_Checked(object sender, RoutedEventArgs e)
        {
            string loan = "Vehicle Loan";
            Customer obj = new Customer()
            {
                LoanType = loan
            };
            instance.GetinterestRateBL(obj);

            MessageBox.Show("move to next page");

        }

       
      
        private void Calculate_Loan_Click(object sender, RoutedEventArgs e)
        {

            Calculator calculator = new Calculator();
            calculator.Show();
            this.Close();
        }

        private void Apply_now_click(object sender, RoutedEventArgs e)
        {
            LoanRegistration loanregistration = new LoanRegistration();
            loanregistration.Show();
            this.Close();
        }
    }
}
