﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LoanManagementPropertiesDL;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for Customeroptions.xaml
    /// </summary>
    public partial class Customeroptions : Window
    {
        public Customeroptions()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            LoanDetails loandetails = new LoanDetails();
            loandetails.Show();
            Login login = new Login();
            Customer customerdetails = new Customer()
            {
                CustomerId = Convert.ToInt32(login.txtCustomerID.Text)
            };
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Types_of_Loans typesofloan = new Types_of_Loans();
            typesofloan.Show();
        }

        private void Update_Details_Click(object sender, RoutedEventArgs e)
        {
            ModifyCustomer modifycustomer = new ModifyCustomer();
            modifycustomer.Show();
            this.Close();
        }
    }
}
