﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LoanManagementPropertiesDL;
using Bussiness_Layer;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for Customeroptions.xaml
    /// </summary>
    public partial class Customeroptions : Window
    {
        public Customeroptions()
        {
            InitializeComponent();
        }
        GetLoanDetailsBL getloandetailsbl = new GetLoanDetailsBL();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            LoanDetails loandetails = new LoanDetails();
            loandetails.Show();
            Login login = new Login();
            Customer customerdetails = new Customer()
            {
                CustomerId = Convert.ToInt32(Login.CustomerIdStat)
            };
            var customer = new Customer();
            customer=getloandetailsbl.GetLoanDetailsbyIDBL(customerdetails);
            loandetails.LoanStatus.Text = Convert.ToString(customer.LoanStatus);
            loandetails.SanctionedAmount.Text = Convert.ToString(customer.SanctionedAmount);
            loandetails.EMI_Months.Text = Convert.ToString(customer.EMIMonths);
            loandetails.EMI_Amount.Text = Convert.ToString(customer.EMIAmount);
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Types_of_Loans typesofloan = new Types_of_Loans();
            typesofloan.Show();
            this.Close();
        }

        private void Update_Details_Click(object sender, RoutedEventArgs e)
        {
            ModifyCustomer modifycustomer = new ModifyCustomer();
            modifycustomer.Show();
            this.Close();
        }

        private void Close_button_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }

        private void Back_Button_click(object sender, RoutedEventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }
    }
}
