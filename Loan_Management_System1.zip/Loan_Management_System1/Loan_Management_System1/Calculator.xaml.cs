﻿using System;
using System.Windows;

namespace Loan_Management_System1
{
    /// <summary>
    /// Interaction logic for HomeLoan.xaml
    /// </summary>
    public partial class Calculator: Window
    {

        double interestrate, monthlyinterestrate,monthlypayment,amount,totalpayment;
        int numberofyears;

      

        string imonthlypayment, itotalpayment;

   

        public Calculator()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }

        public void HomeLoanGetdetails()
        {
           interestrate = 12.00;

        }
        private void Generate_Receipt_Click(object sender, RoutedEventArgs e)
        {
            richTextBox1.AppendText("Loan Management Systems Calculator" + "\n");
            richTextBox1.AppendText("------------------------------------------" + "\n");
            richTextBox1.AppendText("Enter amount of Loan" + "\t" + txt_Loan_Amount.Text + "\n");
            richTextBox1.AppendText("Enter number of Years" + "\t" + txt_Number_Of_Years.Text + "\n");
            richTextBox1.AppendText("Enter Interest Rate" + "\t" + txt_Interest_Rate.Text + "\n");
            richTextBox1.AppendText("Monthly Payment" + "\t" + "\t" + MonthlyPaymentlbl.Content + "\n");
            richTextBox1.AppendText("Total Payment" + "\t" + "\t"  + TotalPaymentlbl.Content + "\n");
            richTextBox1.AppendText("----------------------------------------" + "\n");
            richTextBox1.AppendText("----------------Thank you--------------" + "\n");
        }
        private void Calculate_Button_Click(object sender, RoutedEventArgs e)
        {
            interestrate = Convert.ToDouble(txt_Interest_Rate.Text);
            monthlyinterestrate = interestrate / 1200;
            numberofyears = Convert.ToInt32(txt_Number_Of_Years.Text);
            amount = Convert.ToDouble(txt_Loan_Amount.Text);
            monthlypayment = amount * monthlyinterestrate / (1 - 1 / Math.Pow(1 + monthlyinterestrate, numberofyears * 12));
            imonthlypayment = Convert.ToString(monthlypayment);
            imonthlypayment = String.Format("{0:C}", monthlypayment);
            MonthlyPaymentlbl.Content = (imonthlypayment);
            totalpayment = monthlypayment * numberofyears * 12;
            itotalpayment = String.Format("{0:C}", totalpayment);
            TotalPaymentlbl.Content = (itotalpayment);
            txt_Loan_Amount.Text = String.Format("{0:C}", amount);

        }
        private void Reset_Button_Click(object sender, RoutedEventArgs e)
        {
            txt_Loan_Amount.Clear();
            txt_Interest_Rate.Clear();
            txt_Number_Of_Years.Clear();
            MonthlyPaymentlbl.Content = "";
            TotalPaymentlbl.Content = "";
            richTextBox1.Document.Blocks.Clear();
        }
        private void Back_Button_Click(object sender, RoutedEventArgs e)
        {
            Types_of_Loans typesofloans = new Types_of_Loans();
            typesofloans.Show();
            this.Close();
        }


    }


}

