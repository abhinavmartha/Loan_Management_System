﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Layer
{
    public class Customer
    {
            public string CustomerName { get; set; }
            public int ContactNumber { get; set; }
            public string Email { get; set; }
            public DateTime DOB { get; set; }
            public string PAN{ get; set; }
            public int Aadhar { get; set; }
 
    }
}

