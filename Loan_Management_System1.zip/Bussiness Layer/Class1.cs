﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Layer;
using Domain_Layer;

namespace Bussiness_Layer
{
    public class Customer_BL
    {
        CustomerDL datalayer = new CustomerDL();
        public void InsertCustomer(Customer customer)
        {
            datalayer.InsertCustomerDL(customer);
        }
    }
}
