﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain_Layer;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace Data_Layer
{
    public class CustomerDL
    {
        string dbpath = ConfigurationManager.ConnectionStrings["LoanConnection"].ConnectionString;

        SqlConnection sqlcon;
        SqlCommand sqlcmd;

        public void InsertCustomerDL(Customer customer)
        {
            sqlcon = new SqlConnection(dbpath);
            sqlcon.Open();
        
            sqlcmd = new SqlCommand("usp_Insert_CustomerDetails_Entry", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue ("@CustomerName", customer.CustomerName);
            sqlcmd.Parameters.AddWithValue ("@ContactNumber", customer.ContactNumber);
            sqlcmd.Parameters.AddWithValue ("@Email", customer.Email);
            sqlcmd.Parameters.AddWithValue ("@DOB", customer.DOB);
            sqlcmd.Parameters.AddWithValue ("@PAN", customer.PAN);
            sqlcmd.Parameters.AddWithValue ("@Aadhar", customer.Aadhar);
            sqlcmd.ExecuteNonQuery();
            sqlcon.Close();
            sqlcon.Dispose();

        }
    }
}
